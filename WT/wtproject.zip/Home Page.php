<?php
session_start();

$btn="<a href='#createaccount' style='position: absolute; right:30px; top:10px; text-decoration:none;'>Create Account</a>";
$signin='<a href="#signin" style="position: absolute; right:175px; top:10px; text-decoration:none;">Sign In</a>';
if(isset($_SESSION["username"])){
	
$name =   $_SESSION["username"];
$btn="hello ".$name;
$signin="";
$logout="<a href='logout.php' style='position: absolute; right:30px; top:10px; text-decoration:none;'>logout</a>";

}
?>
<html>
<head>
<title>Sugar & Spice</title>
<script type="text/javascript">
      function validate()
      {
              
		 var emailID = document.myForm.email.value;
         atpos = emailID.indexOf("@");
         dotpos = emailID.lastIndexOf(".");
         
         if (atpos < 1 || ( dotpos - atpos < 2 )) 
         {
            alert("Please enter correct email-ID.")
            document.myForm.email.focus() ;
            return false;
         }
         if( document.myForm.first_name.value == "" || !/^[a-zA-Z]*$/g.test(document.myForm.first_name.value))
         {
            alert( "Invalid First Name. Should contain only characters." );
            document.myForm.first_name.focus() ;
            return false;
         }
		 
		 if( document.myForm.last_name.value == "" || !/^[a-zA-Z]*$/g.test(document.myForm.last_name.value))
         {
            alert( "Invalid Last Name. Should contain only characters." );
            document.myForm.last_name.focus() ;
            return false;
         }
      }
</script>
</head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.span12{padding:30px 0 0}
.copyright{margin:20px 0 10px}

* {box-sizing:border-box}
body {font-family: Verdana,sans-serif;}
.mySlides {display:none}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4}
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .text {font-size: 11px}
}
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}

.button2 {
    background-color: white;
    color: #00ccff;
    border: 2px solid #00ccff;
}

.button2:hover {
    background-color: #33cccc;
    color: white;
}
.modalDialog {
    position: fixed;
	overflow: auto;
    font-family: Arial, Helvetica, sans-serif;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.8);
    z-index: 99999;
    opacity:0;
    -webkit-transition: opacity 400ms ease-in;
    -moz-transition: opacity 400ms ease-in;
    transition: opacity 400ms ease-in;
    pointer-events: none;
}
.modalDialog:target {
    opacity:1;
    pointer-events: auto;
}
.modalDialog > div {
    width: 400px;
    position: relative;
    margin: 10% auto;
    padding: 5px 20px 13px 20px;
    border-radius: 10px;
    background: #99ccff;
}
.close {
    background: #606061;
    color: #FFFFFF;
    line-height: 25px;
    position: absolute;
    right: -12px;
    text-align: center;
    top: -10px;
    width: 24px;
    text-decoration: none;
    font-weight: bold;
    -webkit-border-radius: 12px;
    -moz-border-radius: 12px;
    border-radius: 12px;
    -moz-box-shadow: 1px 1px 3px #000;
    -webkit-box-shadow: 1px 1px 3px #000;
    box-shadow: 1px 1px 3px #000;
}
.close:hover {
    background: #00d9ff;
}
</style>
<body background="Background.jpg">
<?php
error_reporting(0);
echo $btn;?>&nbsp;&nbsp;<?php echo $logout;?>
<div id="createaccount" class="modalDialog">
    <div>	<a href="#close" title="Close" class="close">X</a>

  <form action="create_account.php"  method="post" name="myForm" onsubmit="return(validate());"><center><h3></h3></center>
  <label for="email">Email Address *</label><br>
  <input  type="text" name="email" maxlength="80" size="30" required><br><br>
  Password *<br>
  <input type="password" name="password" required><br><br>
 <label for="first_name">First Name *</label><br>
  <input  type="text" name="first_name" maxlength="50" size="30" required><br><br>
  <label for="last_name">Last Name *</label><br>
  <input  type="text" name="last_name" maxlength="50" size="30" required><br><br>
  Date of Birth:<br>
  <input type="date" name="bday"><br><br>
  Gender:<br>
  <input type="checkbox" name="gender" checked="checked">Male<br>
  <input type="checkbox" name="gender">Female<br><br>
  <input type="submit" value="Create Account" />
</form>
    </div>
</div>
<?php echo $signin;?>
<div id="signin" class="modalDialog">
    <div>	<a href="#close" title="Close" class="close">X</a>
  <form action="login.php" id="create_customer" method="post">  
  <center><h3>SIGN IN</h3></center>
  <label for="email">Email Address *</label><br>
  <input  type="text" name="email" maxlength="80" size="30" required><br><br>
  Password *<br>
  <input type="password" name="password" required><br><br>
  <input type="checkbox" checked="checked">Keep me logged in<br><br>
  <input type="submit" value="Log In" />
  or <a href="Home Page.html">Return to Store</a>
</form>
    </div>
</div>
</div><br><hr>
<a href="Home Page.html">
<center><image src="Logo.jpg" alt="Logo"></center>
</a><br>
<center>
<table>
<tr>
<td>
<a href="Home Page.html">
<button type="button" class="button button2">Home</button></a>
</td>
<td>
<a href="About Us.html">
<button type="button" class="button button2">About Us</button></a>
</td>
<td>
<a href="Menu.html">
<button type="button" class="button button2">Menu</button></a>
</td>
<td>
<a href="Order Online.html">
<button type="button" class="button button2">Order Online</button></a>
</td>
<td>
<a href="Contact.html">
<button type="button" class="button button2">Contact Us</button></a>
</td>
</tr>
</table>
</center><br>
<center>
<div class="slideshow-container">

<div class="mySlides fade">
  <div class="numbertext">1 / 3</div>
  <img src="Red Velvet.jpg" alt="Red Velvet" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">2 / 3</div>
  <img src="Chocolate Vanilla.jpg" alt="Chocolate Vanilla" style="width:100%">
</div>

<div class="mySlides fade">
  <div class="numbertext">3 / 3</div>
  <img src="Double Chocolate.jpg" alt="Double Chocolate" style="width:100%">
</div>

</div>
<br>

<div style="text-align:center">
  <span class="dot"></span>
  <span class="dot"></span>
  <span class="dot"></span>
</div>

<script>
var slideIndex = 0;
showSlides();

function showSlides() {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    var dots = document.getElementsByClassName("dot");
    for (i = 0; i < slides.length; i++) {
       slides[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex> slides.length) {slideIndex = 1}
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex-1].style.display = "block";
    dots[slideIndex-1].className += " active";
    setTimeout(showSlides, 3000); // Change image every 3 seconds
}
</script></center>
<br><center><image src="Cupcakes.jpg" alt="Cupcakes">
<div class="span12 copyright">
          <p>Copyright &copy; 2016 Sugar & Spice | <a href="http://google.com" target="_blank">Sugar & Spice</a>  </p>
            
        </div></center>
</body>
</html>